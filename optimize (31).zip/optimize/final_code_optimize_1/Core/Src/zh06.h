#include <stm32f042x6.h>
volatile static uint32_t a[32]={0};




void DMA_UART_CONFIG(void){
	//DMA CLK ENABLE
  RCC->AHBENR |=(1<<0);

	
	
	//ADDRESS OF USART2 RDR
	DMA1_Channel5->CPAR=(uint32_t)&USART2->RDR;

//ADDRESS OF ARRAY 
	DMA1_Channel5->CMAR=(uint32_t)a;
	
	//NUMBER OF DATA TO BE TRANSFERED
	DMA1_Channel5->CNDTR=32;
	
//MEMORY SIZE 32 BIT
DMA1_Channel5->CCR &=~(1U<<10);
DMA1_Channel5->CCR |=(1U<<11);
	
	//PHERIPERAL SIZE 32BIT
DMA1_Channel5->CCR &=~(1U<<8);
DMA1_Channel5->CCR |=(1U<<9);
	
	//MEMORY INCREMENT MODE
	DMA1_Channel5->CCR |=(1U<<7);
	
	//READ FROM pheripheral
	DMA1_Channel5->CCR &=~(1U<<4);
	
	//TRANSFER COMPLETE INTURRPT ENABLE
	DMA1_Channel5->CCR |=(1U<<1);
	
	//CIRCULAR MODE ENABLE
	DMA1_Channel5->CCR |=(1U<<5);
	
	
	DMA1_Channel5->CCR |=(1U<<12);
	DMA1_Channel5->CCR |=(1U<<13);
	
	
	
	NVIC_EnableIRQ(DMA1_Channel4_5_IRQn); /* (1) */
NVIC_SetPriority(DMA1_Channel4_5_IRQn,0); /* (2) */
	
	
	}

void DMA1_Channel4_5_IRQHandler(void){

	 DMA1->IFCR |=(1<<13);
	DMA1_Channel5->CCR &=~(1U<<1);
	
}


void UART_CONFIG(void){
	
	
	//CONFIGURING THE GND PINS
	
	//enable port F clk
	RCC->AHBENR |=(1<<22);
	
	//General purpose output mode for PF1
	GPIOF->MODER |=(1<<2);
	GPIOF->MODER &=~(1<<3);
	
	//PULL UP PF1
	GPIOF->PUPDR |=(1<<2);
	GPIOF->PUPDR &=~(1<<3);
	
	//Sets the corresponding ODRx bit
	GPIOF->BSRR |=(1<<1);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//enable the UART
	RCC->APB1ENR|=(1<<17);
	//ENABLE THE GPIO CLK
	RCC->AHBENR |=(1<<17);
	
	//CONFIGURE THE UART PINS AS ALT FUNCTIONS
	GPIOA->MODER|=(1<<5);
  GPIOA->MODER &=~(1U<<4);
	GPIOA->MODER|=(1<<7);
	GPIOA->MODER &=~(1U<<6);
	
	//ALTERNATE FUNCTION FOR UART PINS
	GPIOA->AFR[0]|=(1<<8);
	GPIOA->AFR[0]|=(1<<12);
	
	//FIFO ENABLE  ****************************************************************************
	//USART2->CR1 |= (1<<29);
	
	//ENABLE DMA UART
	USART2->CR3 |=(1<<6);
	
	//ENABLE THE UART
	USART2->CR1 |=(1<<0);
	
	//SET THE M BIT TO 8BIT
	USART2->CR1 &=~(1U<<28);
	
	
	
	//SET THE BAUD RATE TO 9600
	USART2->BRR|=(0x0351); //0x0341
	
	
	DMA_UART_CONFIG();
	
	//ENABLE RX AND TX
	USART2->CR1 |=(1<<3);
	USART2->CR1 |=(1<<2);
	//enabble dma
	DMA1_Channel5->CCR |=(1U<<0);

}

